-- ================================================================
-- Al-Mohammadi Umrah Registration — MASTER SQL MIGRATION
-- Paste this entire script into:
--   Supabase Dashboard → SQL Editor → New Query → Run (F5)
-- ================================================================

-- ── 1. Table ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.omra_registrations (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number      text        UNIQUE NOT NULL,
  full_name         text        NOT NULL,
  phone             text        NOT NULL,
  national_id       text        NOT NULL,
  birth_date        date        NOT NULL,
  gender            text        NOT NULL CHECK (gender IN ('ذكر', 'أنثى')),
  governorate       text        NOT NULL,
  city              text        NOT NULL,
  address           text        NOT NULL,
  has_passport      boolean     NOT NULL DEFAULT false,
  passport_number   text,
  passport_expiry   date,
  companions        integer     NOT NULL DEFAULT 1 CHECK (companions BETWEEN 1 AND 50),
  id_front_url      text        NOT NULL,
  id_back_url       text        NOT NULL,
  passport_file_url text,
  notes             text,
  consent           boolean     NOT NULL DEFAULT true,
  created_at        timestamptz NOT NULL DEFAULT now()
);

-- ── 2. Unique constraints (duplicate prevention) ──────────────
ALTER TABLE public.omra_registrations
  DROP CONSTRAINT IF EXISTS omra_unique_national_id;
ALTER TABLE public.omra_registrations
  ADD CONSTRAINT omra_unique_national_id UNIQUE (national_id);

ALTER TABLE public.omra_registrations
  DROP CONSTRAINT IF EXISTS omra_unique_phone;
ALTER TABLE public.omra_registrations
  ADD CONSTRAINT omra_unique_phone UNIQUE (phone);

-- ── 3. Indexes ────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_omra_national_id ON public.omra_registrations (national_id);
CREATE INDEX IF NOT EXISTS idx_omra_phone       ON public.omra_registrations (phone);
CREATE INDEX IF NOT EXISTS idx_omra_created_at  ON public.omra_registrations (created_at DESC);

-- ── 4. Row Level Security ─────────────────────────────────────
ALTER TABLE public.omra_registrations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_registration"           ON public.omra_registrations;
DROP POLICY IF EXISTS "anon_select_for_duplicate_check"   ON public.omra_registrations;

-- Anonymous users can submit new registrations
CREATE POLICY "anon_insert_registration"
  ON public.omra_registrations
  FOR INSERT TO anon
  WITH CHECK (true);

-- Anonymous users can SELECT (needed for duplicate-check queries)
CREATE POLICY "anon_select_for_duplicate_check"
  ON public.omra_registrations
  FOR SELECT TO anon
  USING (true);

-- ── 5. Storage policies (private "registrations" bucket) ──────
DROP POLICY IF EXISTS "anon_upload_registration_files" ON storage.objects;
DROP POLICY IF EXISTS "anon_update_registration_files" ON storage.objects;

-- Allow anonymous users to upload files
CREATE POLICY "anon_upload_registration_files"
  ON storage.objects
  FOR INSERT TO anon
  WITH CHECK (bucket_id = 'registrations');

-- Allow upsert (re-upload if file exists)
CREATE POLICY "anon_update_registration_files"
  ON storage.objects
  FOR UPDATE TO anon
  USING (bucket_id = 'registrations');

-- ── Done ──────────────────────────────────────────────────────
-- After running this script:
-- ✅ Table created with duplicate prevention on national_id + phone
-- ✅ RLS allows anonymous form submissions and duplicate checks
-- ✅ Storage policies allow file uploads to the private bucket
-- ✅ No SELECT/DELETE for anon on storage — files stay private
-- ================================================================
