import { z } from "zod";

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_FILE_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "application/pdf",
];

const fileSchema = z
  .any()
  .refine((files) => files?.length == 1, "الصورة مطلوبة.")
  .refine(
    (files) => files?.[0]?.size <= MAX_FILE_SIZE,
    `الحد الأقصى لحجم الملف هو 5MB.`
  )
  .refine(
    (files) => ACCEPTED_FILE_TYPES.includes(files?.[0]?.type),
    "يجب أن يكون الملف بصيغة .jpg, .jpeg, .png, أو .pdf"
  );

const optionalFileSchema = z
  .any()
  .optional()
  .refine(
    (files) => !files || files.length === 0 || files[0]?.size <= MAX_FILE_SIZE,
    `الحد الأقصى لحجم الملف هو 5MB.`
  )
  .refine(
    (files) => !files || files.length === 0 || ACCEPTED_FILE_TYPES.includes(files[0]?.type),
    "يجب أن يكون الملف بصيغة .jpg, .jpeg, .png, أو .pdf"
  );

export const registrationSchema = z.object({
  fullName: z.string().min(10, "الرجاء إدخال الاسم الرباعي كاملاً"),
  phone: z
    .string()
    .regex(/^01[0125][0-9]{8}$/, "الرجاء إدخال رقم هاتف مصري صحيح (11 رقم)"),
  nationalId: z
    .string()
    .regex(/^[0-9]{14}$/, "الرقم القومي يجب أن يتكون من 14 رقماً"),
  birthDate: z.string().min(1, "تاريخ الميلاد مطلوب"),
  gender: z.enum(["male", "female"], {
    required_error: "الرجاء اختيار النوع",
  }),
  governorate: z.string().min(1, "الرجاء اختيار المحافظة"),
  city: z.string().min(2, "الرجاء إدخال المدينة"),
  address: z.string().min(5, "الرجاء إدخال العنوان بالكامل"),
  hasPassport: z.enum(["yes", "no"], {
    required_error: "الرجاء تحديد ما إذا كان لديك جواز سفر",
  }),
  passportNumber: z.string().optional(),
  passportExpiry: z.string().optional(),
  companions: z.coerce.number().min(1).max(50),
  idFront: fileSchema,
  idBack: fileSchema,
  passportFile: optionalFileSchema,
  notes: z.string().optional(),
  consent: z.literal(true, {
    errorMap: () => ({ message: "يجب الموافقة على الشروط" }),
  }),
}).superRefine((data, ctx) => {
  if (data.hasPassport === "yes") {
    if (!data.passportNumber || data.passportNumber.trim() === "") {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "رقم جواز السفر مطلوب",
        path: ["passportNumber"],
      });
    }
    if (!data.passportExpiry || data.passportExpiry.trim() === "") {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "تاريخ انتهاء الجواز مطلوب",
        path: ["passportExpiry"],
      });
    }
  }
});

export type RegistrationFormValues = z.infer<typeof registrationSchema>;
