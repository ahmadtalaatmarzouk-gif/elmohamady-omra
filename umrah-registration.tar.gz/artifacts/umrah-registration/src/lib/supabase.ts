import { createClient, SupabaseClient } from "@supabase/supabase-js";

let _client: SupabaseClient | null = null;

function getClient(): SupabaseClient {
  if (_client) return _client;

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

  if (!supabaseUrl || !supabaseUrl.startsWith("http")) {
    throw new Error("إعداد Supabase URL غير صحيح. يرجى التحقق من إعدادات المشروع.");
  }
  if (!supabaseAnonKey || supabaseAnonKey.length < 20) {
    throw new Error("إعداد Supabase Key غير صحيح. يرجى التحقق من إعدادات المشروع.");
  }

  _client = createClient(supabaseUrl, supabaseAnonKey);
  return _client;
}

export async function checkDuplicate(
  field: "national_id" | "phone",
  value: string
): Promise<boolean> {
  const client = getClient();
  const { data } = await client
    .from("omra_registrations")
    .select("id")
    .eq(field, value)
    .maybeSingle();
  return !!data;
}

export async function insertRegistration(record: Record<string, unknown>) {
  const client = getClient();
  const { error } = await client.from("omra_registrations").insert(record);
  if (error) throw new Error(error.message);
}

/**
 * Uploads a file to the private "registrations" bucket.
 * Returns the storage PATH (not a public URL) since the bucket is private.
 * Admins can generate signed URLs from these paths via the Supabase dashboard.
 */
export async function uploadFile(
  storagePath: string,
  file: File
): Promise<string> {
  const client = getClient();
  const { error } = await client.storage
    .from("registrations")
    .upload(storagePath, file, { cacheControl: "3600", upsert: true });

  if (error) throw new Error(`فشل رفع الملف: ${error.message}`);

  return storagePath;
}

export async function fetchRegistrations(opts: {
  search?: string;
  governorate?: string;
  page: number;
  pageSize: number;
}) {
  const client = getClient();
  let query = client
    .from("omra_registrations")
    .select("*", { count: "exact" })
    .order("created_at", { ascending: false })
    .range(opts.page * opts.pageSize, (opts.page + 1) * opts.pageSize - 1);

  if (opts.search && opts.search.trim()) {
    query = query.or(
      `full_name.ilike.%${opts.search}%,national_id.ilike.%${opts.search}%,phone.ilike.%${opts.search}%,order_number.ilike.%${opts.search}%`
    );
  }
  if (opts.governorate && opts.governorate !== "all") {
    query = query.eq("governorate", opts.governorate);
  }

  const { data, error, count } = await query;
  if (error) throw new Error(error.message);
  return { rows: data ?? [], total: count ?? 0 };
}

export async function fetchAllRegistrations(opts: {
  search?: string;
  governorate?: string;
}) {
  const client = getClient();
  let query = client
    .from("omra_registrations")
    .select("*")
    .order("created_at", { ascending: false });

  if (opts.search && opts.search.trim()) {
    query = query.or(
      `full_name.ilike.%${opts.search}%,national_id.ilike.%${opts.search}%,phone.ilike.%${opts.search}%,order_number.ilike.%${opts.search}%`
    );
  }
  if (opts.governorate && opts.governorate !== "all") {
    query = query.eq("governorate", opts.governorate);
  }

  const { data, error } = await query;
  if (error) throw new Error(error.message);
  return data ?? [];
}
