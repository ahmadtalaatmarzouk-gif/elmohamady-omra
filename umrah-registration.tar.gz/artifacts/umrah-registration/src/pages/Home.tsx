import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "framer-motion";
import { Send, CheckCircle, UploadCloud, MapPin, Clock, Phone, Share2, Map, Loader2, AlertCircle } from "lucide-react";
import { checkDuplicate, insertRegistration, uploadFile } from "@/lib/supabase";
import { FaWhatsapp } from "react-icons/fa";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";

import { registrationSchema, type RegistrationFormValues } from "@/lib/validation";

const EGYPTIAN_GOVERNORATES = [
  "القاهرة", "الإسكندرية", "الجيزة", "القليوبية", "الشرقية", "الدقهلية",
  "البحيرة", "المنوفية", "الغربية", "كفر الشيخ", "دمياط", "بورسعيد",
  "الإسماعيلية", "السويس", "شمال سيناء", "جنوب سيناء", "الفيوم", "بني سويف",
  "المنيا", "أسيوط", "سوهاج", "قنا", "الأقصر", "أسوان", "البحر الأحمر",
  "الوادي الجديد", "مطروح"
];

export default function Home() {
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [orderNumber, setOrderNumber] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const form = useForm<RegistrationFormValues>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      fullName: "",
      phone: "",
      nationalId: "",
      birthDate: "",
      city: "",
      address: "",
      companions: 1,
      notes: "",
    },
  });

  const hasPassport = form.watch("hasPassport");

  const onSubmit = async (data: RegistrationFormValues) => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      // Check for duplicate national ID
      const isDuplicateNationalId = await checkDuplicate("national_id", data.nationalId);
      if (isDuplicateNationalId) {
        setSubmitError("هذا الرقم القومي مسجل مسبقاً. إذا كنت بحاجة لمساعدة، يرجى التواصل معنا.");
        setIsSubmitting(false);
        return;
      }

      // Check for duplicate phone
      const isDuplicatePhone = await checkDuplicate("phone", data.phone);
      if (isDuplicatePhone) {
        setSubmitError("رقم الهاتف هذا مسجل مسبقاً. إذا كنت بحاجة لمساعدة، يرجى التواصل معنا.");
        setIsSubmitting(false);
        return;
      }

      // Generate order number
      const randomNum = Math.floor(10000 + Math.random() * 90000);
      const generatedOrderNumber = `MH-2026-${randomNum}`;

      // Upload files to Supabase Storage
      const timestamp = Date.now();
      const safeName = data.nationalId;

      const idFrontFile = data.idFront[0] as File;
      const idBackFile = data.idBack[0] as File;

      const idFrontExt = idFrontFile.name.split(".").pop();
      const idBackExt  = idBackFile.name.split(".").pop();

      const idFrontUrl = await uploadFile(
        `${safeName}/${timestamp}_id_front.${idFrontExt}`,
        idFrontFile
      );

      const idBackUrl = await uploadFile(
        `${safeName}/${timestamp}_id_back.${idBackExt}`,
        idBackFile
      );

      let passportFileUrl: string | null = null;
      if (data.passportFile && data.passportFile.length > 0) {
        const passportFile = data.passportFile[0] as File;
        const passportExt  = passportFile.name.split(".").pop();
        passportFileUrl = await uploadFile(
          `${safeName}/${timestamp}_passport.${passportExt}`,
          passportFile
        );
      }

      // Insert registration record
      await insertRegistration({
        order_number: generatedOrderNumber,
        full_name: data.fullName,
        phone: data.phone,
        national_id: data.nationalId,
        birth_date: data.birthDate,
        gender: data.gender === "male" ? "ذكر" : "أنثى",
        governorate: data.governorate,
        city: data.city,
        address: data.address,
        has_passport: data.hasPassport === "yes",
        passport_number: data.passportNumber ?? null,
        passport_expiry: data.passportExpiry ?? null,
        companions: data.companions,
        id_front_url: idFrontUrl,
        id_back_url: idBackUrl,
        passport_file_url: passportFileUrl,
        notes: data.notes ?? null,
        consent: data.consent,
      });

      setOrderNumber(generatedOrderNumber);
      setIsSuccessModalOpen(true);
      form.reset();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "حدث خطأ غير متوقع";
      setSubmitError(`حدث خطأ أثناء إرسال الطلب: ${msg}. يرجى المحاولة مرة أخرى.`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "تسجيل طلب العمرة - المحمدي للسياحة",
          url: window.location.href,
        });
      } catch (err) {
        console.error(err);
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("تم نسخ الرابط!");
    }
  };

  // Helper component for file uploads
  const FileUploadField = ({ name, label, optional = false }: { name: any, label: string, optional?: boolean }) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field: { value, onChange, ...field } }) => (
        <FormItem>
          <FormLabel>{label} {optional && <span className="text-muted-foreground">(اختياري)</span>}</FormLabel>
          <FormControl>
            <div className="relative flex flex-col items-center justify-center p-6 border-2 border-dashed border-primary/30 rounded-xl bg-primary/5 hover:bg-primary/10 transition-colors cursor-pointer group">
              <UploadCloud className="w-8 h-8 text-primary mb-2 group-hover:scale-110 transition-transform" />
              <div className="text-sm font-medium">اضغط لاختيار ملف أو اسحب الملف هنا</div>
              <div className="text-xs text-muted-foreground mt-1">.jpg, .png, .pdf (بحد أقصى 5MB)</div>
              {value && value.length > 0 && (
                <div className="mt-4 p-2 bg-background/50 rounded text-sm w-full text-center truncate">
                  تم اختيار: {value[0].name}
                </div>
              )}
              <input
                type="file"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                accept=".jpg,.jpeg,.png,.pdf"
                onChange={(e) => {
                  onChange(e.target.files);
                }}
                {...field}
              />
            </div>
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <div dir="rtl" className="min-h-screen text-foreground py-12 px-4 sm:px-6 lg:px-8 font-sans">
      
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-4xl mx-auto text-center mb-12"
      >
        <div className="inline-block p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl mb-6">
          <img src="/logo.jpeg" alt="المحمدي للسياحة" className="h-24 object-contain rounded-lg" />
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-[0_2px_10px_rgba(0,0,0,0.5)] tracking-tight">
          تسجيل طلب العمرة
        </h1>
        <p className="text-lg text-white/80 max-w-2xl mx-auto">
          يرجى تعبئة البيانات التالية، وسيقوم فريق المحمدي للسياحة بالتواصل معكم في أقرب وقت.
        </p>
      </motion.div>

      {/* Main Form */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="max-w-4xl mx-auto"
      >
        <Card className="backdrop-blur-xl bg-card border-white/10 shadow-2xl shadow-purple-900/20">
          <CardContent className="p-6 md:p-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                
                {/* Personal Information */}
                <div className="space-y-6">
                  <h2 className="text-2xl font-semibold text-primary border-b border-white/10 pb-2">البيانات الشخصية</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الاسم الرباعي</FormLabel>
                          <FormControl>
                            <Input placeholder="أدخل الاسم كاملًا" {...field} className="bg-background/50 border-white/10" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>رقم الهاتف</FormLabel>
                          <FormControl>
                            <Input placeholder="01xxxxxxxxx" dir="ltr" className="text-right bg-background/50 border-white/10" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="nationalId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الرقم القومي</FormLabel>
                          <FormControl>
                            <Input placeholder="14 رقم" dir="ltr" className="text-right bg-background/50 border-white/10" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="birthDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>تاريخ الميلاد</FormLabel>
                          <FormControl>
                            <Input type="date" className="bg-background/50 border-white/10 block w-full" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>النوع</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex gap-4"
                            >
                              <FormItem className="flex items-center space-x-2 space-x-reverse">
                                <FormControl>
                                  <RadioGroupItem value="male" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">ذكر</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2 space-x-reverse">
                                <FormControl>
                                  <RadioGroupItem value="female" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer">أنثى</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Address */}
                <div className="space-y-6">
                  <h2 className="text-2xl font-semibold text-primary border-b border-white/10 pb-2">بيانات السكن</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="governorate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>المحافظة</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-background/50 border-white/10">
                                <SelectValue placeholder="اختر المحافظة" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-popover border-white/10">
                              {EGYPTIAN_GOVERNORATES.map(gov => (
                                <SelectItem key={gov} value={gov}>{gov}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>المدينة/المركز</FormLabel>
                          <FormControl>
                            <Input placeholder="المدينة" className="bg-background/50 border-white/10" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem className="md:col-span-2">
                          <FormLabel>العنوان بالكامل</FormLabel>
                          <FormControl>
                            <Textarea placeholder="العنوان بالتفصيل" className="bg-background/50 border-white/10 resize-none" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Passport & Trip Info */}
                <div className="space-y-6">
                  <h2 className="text-2xl font-semibold text-primary border-b border-white/10 pb-2">بيانات السفر</h2>
                  
                  <FormField
                    control={form.control}
                    name="hasPassport"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>هل لديك جواز سفر؟</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex gap-4"
                          >
                            <FormItem className="flex items-center space-x-2 space-x-reverse">
                              <FormControl>
                                <RadioGroupItem value="yes" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">نعم</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-x-reverse">
                              <FormControl>
                                <RadioGroupItem value="no" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">لا</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <AnimatePresence>
                    {hasPassport === "yes" && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                          <FormField
                            control={form.control}
                            name="passportNumber"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>رقم جواز السفر</FormLabel>
                                <FormControl>
                                  <Input dir="ltr" className="text-right bg-background/50 border-white/10" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="passportExpiry"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>تاريخ انتهاء الجواز</FormLabel>
                                <FormControl>
                                  <Input type="date" className="bg-background/50 border-white/10 block w-full" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <FormField
                    control={form.control}
                    name="companions"
                    render={({ field }) => (
                      <FormItem className="md:w-1/2">
                        <FormLabel>عدد المعتمرين (بما فيهم أنت)</FormLabel>
                        <FormControl>
                          <Input type="number" min={1} max={50} className="bg-background/50 border-white/10" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* File Uploads */}
                <div className="space-y-6">
                  <h2 className="text-2xl font-semibold text-primary border-b border-white/10 pb-2">المرفقات</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FileUploadField name="idFront" label="رفع صورة البطاقة (الوجه الأمامي)" />
                    <FileUploadField name="idBack" label="رفع صورة البطاقة (الوجه الخلفي)" />
                    <div className="md:col-span-2">
                      <FileUploadField name="passportFile" label="رفع صورة جواز السفر" optional />
                    </div>
                  </div>
                </div>

                {/* Additional & Consent */}
                <div className="space-y-6">
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ملاحظات إضافية <span className="text-muted-foreground">(اختياري)</span></FormLabel>
                        <FormControl>
                          <Textarea placeholder="أي ملاحظات أو طلبات خاصة" className="bg-background/50 border-white/10 resize-none min-h-[100px]" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="consent"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-x-reverse space-y-0 p-4 bg-background/30 border border-white/10 rounded-lg">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel className="cursor-pointer">
                            أوافق على استخدام بياناتي للتواصل معي بخصوص طلب العمرة.
                          </FormLabel>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {submitError && (
                  <div className="flex items-start gap-3 p-4 bg-red-500/10 border border-red-500/30 rounded-xl text-red-300 text-sm">
                    <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                    <span>{submitError}</span>
                  </div>
                )}

                <Button 
                  type="submit" 
                  size="lg" 
                  disabled={isSubmitting}
                  className="w-full text-lg h-14 bg-gradient-to-r from-primary to-purple-800 hover:from-primary/90 hover:to-purple-800/90 text-white border-0 shadow-xl shadow-primary/20 transition-all hover:scale-[1.01] disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="ml-2 h-5 w-5 animate-spin" />
                      جارٍ إرسال الطلب...
                    </>
                  ) : (
                    <>
                      <Send className="ml-2 h-5 w-5" />
                      إرسال الطلب
                    </>
                  )}
                </Button>

              </form>
            </Form>
          </CardContent>
        </Card>
      </motion.div>

      {/* Footer Contact Section */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="max-w-4xl mx-auto mt-12"
      >
        <Card className="backdrop-blur-xl bg-card border-white/10 overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent pointer-events-none" />
          <CardContent className="p-6 md:p-8 relative z-10">
            <h3 className="text-2xl font-bold mb-6 text-center text-white">تواصل معنا</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-primary shrink-0 mt-1" />
                  <div>
                    <strong className="block text-white mb-1">العنوان:</strong>
                    <p className="text-white/70 leading-relaxed">القاهرة، المرج، مؤسسة الزكاة، محطة المدرسة، عمارة أولاد بخيت، الدور الثاني.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-primary shrink-0 mt-1" />
                  <div>
                    <strong className="block text-white mb-1">مواعيد العمل:</strong>
                    <p className="text-white/70">من السبت إلى الخميس — 12:00 ظهرًا حتى 10:00 مساءً</p>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-primary shrink-0 mt-1" />
                  <div>
                    <strong className="block text-white mb-1">أرقام التواصل:</strong>
                    <div className="flex flex-col gap-1 text-white/70" dir="ltr">
                      <a href="tel:01125966936" className="hover:text-primary transition-colors text-right">01125966936</a>
                      <a href="tel:01095389555" className="hover:text-primary transition-colors text-right">01095389555</a>
                      <a href="tel:01115653011" className="hover:text-primary transition-colors text-right">01115653011</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button asChild variant="outline" className="bg-white/5 border-white/10 hover:bg-white/10">
                <a href="tel:01125966936">
                  <Phone className="mr-2 h-4 w-4" /> اتصال مباشر
                </a>
              </Button>
              <Button asChild variant="outline" className="bg-white/5 border-white/10 hover:bg-white/10 hover:text-green-400">
                <a href="https://wa.me/201125966936" target="_blank" rel="noopener noreferrer">
                  <FaWhatsapp className="mr-2 h-5 w-5" /> واتساب
                </a>
              </Button>
              <Button variant="outline" className="bg-white/5 border-white/10 hover:bg-white/10" onClick={handleShare}>
                <Share2 className="mr-2 h-4 w-4" /> مشاركة الصفحة
              </Button>
              <Button asChild variant="outline" className="bg-white/5 border-white/10 hover:bg-white/10 hover:text-blue-400">
                <a href="https://maps.google.com/?q=القاهرة،+المرج،+مؤسسة+الزكاة" target="_blank" rel="noopener noreferrer">
                  <Map className="mr-2 h-4 w-4" /> خرائط Google
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Success Modal */}
      <Dialog open={isSuccessModalOpen} onOpenChange={setIsSuccessModalOpen}>
        <DialogContent className="sm:max-w-md bg-card border-white/10" dir="rtl">
          <DialogHeader className="text-center sm:text-center space-y-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", bounce: 0.5 }}
              className="mx-auto bg-green-500/20 p-3 rounded-full w-fit"
            >
              <CheckCircle className="w-12 h-12 text-green-500" />
            </motion.div>
            <DialogTitle className="text-2xl text-center">✅ تم استلام طلبكم بنجاح.</DialogTitle>
            <DialogDescription className="text-center text-lg text-white/70">
              سيقوم فريق المحمدي للسياحة بالتواصل معكم في أقرب وقت.
            </DialogDescription>
          </DialogHeader>
          <div className="bg-background/50 p-4 rounded-lg mt-4 text-center border border-white/5">
            <p className="text-sm text-white/60 mb-1">رقم الطلب</p>
            <p className="text-2xl font-mono text-primary font-bold">{orderNumber}</p>
          </div>
          <div className="mt-6 flex justify-center">
            <DialogClose asChild>
              <Button variant="default" className="w-full h-12 text-lg bg-primary hover:bg-primary/90 text-white">إغلاق</Button>
            </DialogClose>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
