import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Search, RefreshCw, LogOut, Eye, Download, Users, UserCheck, Calendar } from "lucide-react";
import * as XLSX from "xlsx";

import { fetchRegistrations, fetchAllRegistrations } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

const EGYPTIAN_GOVERNORATES = [
  "القاهرة", "الإسكندرية", "الجيزة", "القليوبية", "الشرقية", "الدقهلية",
  "البحيرة", "المنوفية", "الغربية", "كفر الشيخ", "دمياط", "بورسعيد",
  "الإسماعيلية", "السويس", "شمال سيناء", "جنوب سيناء", "الفيوم", "بني سويف",
  "المنيا", "أسيوط", "سوهاج", "قنا", "الأقصر", "أسوان", "البحر الأحمر",
  "الوادي الجديد", "مطروح"
];

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const [search, setSearch] = useState("");
  const [governorate, setGovernorate] = useState("all");
  const [page, setPage] = useState(0);
  const pageSize = 10;

  const [selectedRecord, setSelectedRecord] = useState<any>(null);

  useEffect(() => {
    if (sessionStorage.getItem("admin_auth") === "true") {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "mohammadi2026") {
      sessionStorage.setItem("admin_auth", "true");
      setIsAuthenticated(true);
      setPasswordError("");
    } else {
      setPasswordError("كلمة المرور غير صحيحة");
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem("admin_auth");
    setIsAuthenticated(false);
    setPassword("");
  };

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["registrations", search, governorate, page],
    queryFn: () => fetchRegistrations({ search, governorate, page, pageSize }),
    enabled: isAuthenticated,
  });

  const exportToExcel = async () => {
    try {
      const rows = await fetchAllRegistrations({ search, governorate: governorate === "all" ? undefined : governorate });
      const exportData = rows.map(r => ({
        "رقم الطلب": r.order_number,
        "الاسم الرباعي": r.full_name,
        "رقم الهاتف": r.phone,
        "الرقم القومي": r.national_id,
        "تاريخ الميلاد": r.birth_date,
        "النوع": r.gender,
        "المحافظة": r.governorate,
        "المدينة": r.city,
        "العنوان": r.address,
        "جواز سفر": r.has_passport ? "نعم" : "لا",
        "رقم الجواز": r.passport_number ?? "",
        "انتهاء الجواز": r.passport_expiry ?? "",
        "عدد المعتمرين": r.companions,
        "ملاحظات": r.notes ?? "",
        "تاريخ التسجيل": new Date(r.created_at).toLocaleDateString("ar-EG"),
      }));
      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "الطلبات");
      XLSX.writeFile(wb, `registrations_${Date.now()}.xlsx`);
    } catch (err) {
      console.error(err);
      alert("حدث خطأ أثناء تصدير الملف.");
    }
  };

  if (!isAuthenticated) {
    return (
      <div dir="rtl" className="min-h-screen flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md"
        >
          <Card className="backdrop-blur-xl bg-card border-white/10 shadow-2xl">
            <CardHeader className="text-center space-y-4">
              <div className="mx-auto bg-white/5 p-4 rounded-2xl w-24 h-24 flex items-center justify-center border border-white/10">
                <img src="/logo.jpeg" alt="Logo" className="rounded-lg object-contain w-full h-full" />
              </div>
              <CardTitle className="text-2xl font-bold text-white">لوحة تحكم المحمدي</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Input 
                    type="password" 
                    placeholder="كلمة المرور" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-background/50 border-white/10 text-center text-lg"
                    dir="ltr"
                  />
                  {passwordError && (
                    <p className="text-destructive text-sm text-center">{passwordError}</p>
                  )}
                </div>
                <Button type="submit" className="w-full text-lg h-12">دخول</Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  const todayStr = new Date().toLocaleDateString("ar-EG");
  // Basic derived stats assuming data.rows is current page, we don't have total stats unless fetched separately.
  // We'll show stats just as general placeholders or based on total from query if possible, but total only gives count.
  const totalCount = data?.total ?? 0;

  return (
    <div dir="rtl" className="min-h-screen pb-12 font-sans">
      <header className="bg-card/80 backdrop-blur-xl border-b border-white/10 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src="/logo.jpeg" alt="Logo" className="h-12 rounded" />
            <h1 className="text-2xl font-bold text-white hidden sm:block">لوحة تحكم الطلبات</h1>
          </div>
          <Button variant="outline" className="border-white/10 bg-background/50 hover:bg-white/10" onClick={handleLogout}>
            <LogOut className="w-4 h-4 ml-2" />
            تسجيل خروج
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 space-y-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-card/60 backdrop-blur-md border-white/10">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-4 bg-primary/20 rounded-xl text-primary">
                <Users className="w-8 h-8" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">إجمالي الطلبات (المطابقة للبحث)</p>
                <p className="text-3xl font-bold text-white mt-1">{totalCount}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card/60 backdrop-blur-md border-white/10">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-4 bg-primary/20 rounded-xl text-primary">
                <Calendar className="w-8 h-8" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">التاريخ</p>
                <p className="text-xl font-bold text-white mt-2">{todayStr}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card/60 backdrop-blur-md border-white/10">
            <CardContent className="p-6 flex items-center justify-center">
              <Button onClick={exportToExcel} className="w-full h-full text-lg py-4 bg-green-600 hover:bg-green-700 text-white">
                <Download className="w-5 h-5 ml-2" />
                تصدير Excel
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="bg-card/80 backdrop-blur-xl border-white/10">
          <CardContent className="p-6 flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input 
                placeholder="بحث بالاسم، الرقم القومي، الهاتف، رقم الطلب..." 
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(0); }}
                className="pl-4 pr-10 bg-background/50 border-white/10 w-full"
              />
            </div>
            <div className="w-full md:w-64">
              <Select value={governorate} onValueChange={(v) => { setGovernorate(v); setPage(0); }}>
                <SelectTrigger className="bg-background/50 border-white/10">
                  <SelectValue placeholder="المحافظة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  {EGYPTIAN_GOVERNORATES.map(gov => (
                    <SelectItem key={gov} value={gov}>{gov}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" className="w-full md:w-auto border-white/10 bg-background/50 hover:bg-white/10" onClick={() => refetch()}>
              <RefreshCw className="w-4 h-4 ml-2" />
              تحديث
            </Button>
          </CardContent>
        </Card>

        {/* Table */}
        <Card className="bg-card/80 backdrop-blur-xl border-white/10 overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/10 hover:bg-transparent">
                  <TableHead className="text-right text-white">رقم الطلب</TableHead>
                  <TableHead className="text-right text-white">الاسم</TableHead>
                  <TableHead className="text-right text-white">الهاتف</TableHead>
                  <TableHead className="text-right text-white">الرقم القومي</TableHead>
                  <TableHead className="text-right text-white">المحافظة</TableHead>
                  <TableHead className="text-center text-white">عدد المعتمرين</TableHead>
                  <TableHead className="text-right text-white">تاريخ التسجيل</TableHead>
                  <TableHead className="text-center text-white">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      جاري التحميل...
                    </TableCell>
                  </TableRow>
                ) : error ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-destructive">
                      حدث خطأ أثناء جلب البيانات
                    </TableCell>
                  </TableRow>
                ) : data?.rows.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      لا توجد طلبات مطابقة
                    </TableCell>
                  </TableRow>
                ) : (
                  data?.rows.map((row) => (
                    <TableRow key={row.id} className="border-white/10 hover:bg-white/5 transition-colors">
                      <TableCell className="font-mono text-sm">{row.order_number}</TableCell>
                      <TableCell className="font-medium text-white">{row.full_name}</TableCell>
                      <TableCell className="font-mono text-sm" dir="ltr">{row.phone}</TableCell>
                      <TableCell className="font-mono text-sm" dir="ltr">{row.national_id}</TableCell>
                      <TableCell>{row.governorate}</TableCell>
                      <TableCell className="text-center">{row.companions}</TableCell>
                      <TableCell className="text-sm">
                        {new Date(row.created_at).toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" })}
                      </TableCell>
                      <TableCell className="text-center">
                        <Button variant="ghost" size="icon" className="hover:bg-white/10 text-primary" onClick={() => setSelectedRecord(row)}>
                          <Eye className="w-5 h-5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          {/* Pagination */}
          {totalCount > 0 && (
            <div className="p-4 border-t border-white/10 flex items-center justify-between bg-white/5">
              <div className="text-sm text-muted-foreground">
                عرض {page * pageSize + 1} إلى {Math.min((page + 1) * pageSize, totalCount)} من {totalCount}
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-white/10 bg-background/50 hover:bg-white/10"
                  onClick={() => setPage(p => Math.max(0, p - 1))}
                  disabled={page === 0}
                >
                  السابق
                </Button>
                <div className="px-4 py-2 text-sm bg-primary/20 text-primary rounded-md font-medium">
                  {page + 1}
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-white/10 bg-background/50 hover:bg-white/10"
                  onClick={() => setPage(p => p + 1)}
                  disabled={(page + 1) * pageSize >= totalCount}
                >
                  التالي
                </Button>
              </div>
            </div>
          )}
        </Card>

      </main>

      {/* Details Modal */}
      <Dialog open={!!selectedRecord} onOpenChange={(o) => !o && setSelectedRecord(null)}>
        <DialogContent dir="rtl" className="max-w-2xl max-h-[90vh] overflow-y-auto bg-card/95 backdrop-blur-xl border-white/10">
          <DialogHeader>
            <DialogTitle className="text-2xl text-primary mb-4 border-b border-white/10 pb-4">تفاصيل الطلب: <span className="text-white ml-2 font-mono">{selectedRecord?.order_number}</span></DialogTitle>
            <DialogDescription className="sr-only">تفاصيل التسجيل</DialogDescription>
          </DialogHeader>
          
          {selectedRecord && (
            <div className="space-y-6 text-sm md:text-base">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><span className="text-muted-foreground">الاسم:</span> <p className="font-medium text-white text-lg">{selectedRecord.full_name}</p></div>
                <div><span className="text-muted-foreground">تاريخ التسجيل:</span> <p className="font-medium text-white">{new Date(selectedRecord.created_at).toLocaleString("ar-EG")}</p></div>
                <div><span className="text-muted-foreground">الهاتف:</span> <p className="font-medium text-white font-mono" dir="ltr">{selectedRecord.phone}</p></div>
                <div><span className="text-muted-foreground">الرقم القومي:</span> <p className="font-medium text-white font-mono" dir="ltr">{selectedRecord.national_id}</p></div>
                <div><span className="text-muted-foreground">النوع:</span> <p className="font-medium text-white">{selectedRecord.gender}</p></div>
                <div><span className="text-muted-foreground">تاريخ الميلاد:</span> <p className="font-medium text-white">{selectedRecord.birth_date}</p></div>
                <div><span className="text-muted-foreground">المحافظة:</span> <p className="font-medium text-white">{selectedRecord.governorate}</p></div>
                <div><span className="text-muted-foreground">المدينة:</span> <p className="font-medium text-white">{selectedRecord.city}</p></div>
                <div className="md:col-span-2"><span className="text-muted-foreground">العنوان:</span> <p className="font-medium text-white">{selectedRecord.address}</p></div>
                <div><span className="text-muted-foreground">عدد المعتمرين:</span> <p className="font-medium text-white">{selectedRecord.companions}</p></div>
              </div>

              {selectedRecord.has_passport && (
                <div className="p-4 bg-primary/10 rounded-xl border border-primary/20 space-y-4 mt-6">
                  <h3 className="font-semibold text-primary flex items-center gap-2">
                    <UserCheck className="w-5 h-5" />
                    بيانات جواز السفر
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><span className="text-muted-foreground">رقم الجواز:</span> <p className="font-medium text-white font-mono" dir="ltr">{selectedRecord.passport_number}</p></div>
                    <div><span className="text-muted-foreground">تاريخ الانتهاء:</span> <p className="font-medium text-white">{selectedRecord.passport_expiry}</p></div>
                  </div>
                </div>
              )}

              {selectedRecord.notes && (
                <div className="mt-4">
                  <span className="text-muted-foreground">ملاحظات:</span> 
                  <p className="font-medium text-white p-3 bg-white/5 rounded-lg border border-white/10 mt-1 whitespace-pre-wrap">{selectedRecord.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
